"""Command-line interface:  python -m nta {analyze,sample,capture} ..."""
from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .analyzer import SEVERITIES, Thresholds, TrafficAnalyzer
from .pcap_reader import iter_packets
from .report import console_summary, write_reports


def _analyze(a) -> int:
    th = Thresholds(scan_ports=a.scan_ports, sweep_hosts=a.sweep_hosts, syn_flood_syns=a.syn_flood)
    try:
        result = TrafficAnalyzer(th).analyze(iter_packets(a.pcap), os.path.basename(a.pcap))
    except (OSError, ValueError) as e:
        print(f"[error] {e}", file=sys.stderr)
        return 1
    name = a.name or os.path.splitext(os.path.basename(a.pcap))[0]
    print(console_summary(result))
    paths = write_reports(result, a.out_dir, name, tuple(a.formats.split(",")), a.charts)
    print("\nWrote:\n  " + "\n  ".join(paths))
    if a.fail_on:
        limit = SEVERITIES.index(a.fail_on)
        if any(SEVERITIES.index(f.severity) <= limit for f in result.findings):
            return 2
    return 0


def _sample(a) -> int:
    from .sample_gen import generate
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    n = generate(a.out, a.seed, not a.baseline_only, a.pcapng)
    print(f"[+] Wrote {n} synthetic packets to {a.out}")
    return 0


def _capture(a) -> int:
    from .capture import capture
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    capture(a.iface, a.duration, a.out, a.filter)
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="nta", description="Network Traffic Analyzer")
    p.add_argument("--version", action="version", version=f"nta {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze", help="analyze a .pcap/.pcapng file")
    a.add_argument("pcap")
    a.add_argument("-o", "--out-dir", default="reports")
    a.add_argument("--name", help="output file prefix (default: capture file name)")
    a.add_argument("--formats", default="md,json", help="comma list of: md,json")
    a.add_argument("--charts", action="store_true", help="also write PNG charts (needs matplotlib)")
    a.add_argument("--scan-ports", type=int, default=15, help="distinct ports that count as a scan")
    a.add_argument("--sweep-hosts", type=int, default=10, help="distinct hosts that count as a sweep")
    a.add_argument("--syn-flood", type=int, default=100, help="SYNs to one service that count as a flood")
    a.add_argument("--fail-on", choices=SEVERITIES, help="exit code 2 if a finding at/above this severity exists")
    a.set_defaults(func=_analyze)

    s = sub.add_parser("sample", help="generate the synthetic demo capture")
    s.add_argument("--out", default="samples/sample_traffic.pcap")
    s.add_argument("--seed", type=int, default=7)
    s.add_argument("--pcapng", action="store_true")
    s.add_argument("--baseline-only", action="store_true", help="benign traffic only")
    s.set_defaults(func=_sample)

    c = sub.add_parser("capture", help="live capture with Scapy (requires privileges)")
    c.add_argument("--iface", default="")
    c.add_argument("--duration", type=int, default=60)
    c.add_argument("--out", default="captures/capture.pcap")
    c.add_argument("--filter", help="BPF filter, e.g. 'not port 22'")
    c.set_defaults(func=_capture)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
