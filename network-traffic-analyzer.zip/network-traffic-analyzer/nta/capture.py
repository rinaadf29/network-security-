"""Optional live capture using Scapy (needs root/Administrator and Npcap on Windows).

Only capture on networks you own or are explicitly authorised to monitor.
You can equally capture with Wireshark / tcpdump / tshark and feed the file to ``nta analyze``.
"""
from __future__ import annotations


def capture(iface: str, duration: int, out: str, bpf: str | None = None) -> int:
    try:
        from scapy.all import sniff, wrpcap
    except ImportError:
        raise SystemExit("Scapy is not installed. Run: pip install scapy\n"
                         "Alternatively capture with Wireshark/tcpdump and run 'nta analyze'.")
    print(f"[*] Capturing on {iface or 'default interface'} for {duration}s (filter: {bpf or 'none'}) ...")
    pkts = sniff(iface=iface or None, timeout=duration, filter=bpf)
    wrpcap(out, pkts)
    print(f"[+] Saved {len(pkts)} packets to {out}")
    return len(pkts)
