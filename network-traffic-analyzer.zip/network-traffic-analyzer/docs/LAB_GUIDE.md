# Lab Guide: Capturing and Analysing Your Own Traffic

The repo ships with a **synthetic** capture so it works out of the box. For a stronger submission, add a capture
from **your own isolated lab** and include its report next to the sample one.

## 1. Rules of engagement
* Only capture/test machines **you own** or have written permission to test.
* Keep the lab on an isolated network (VirtualBox *Host-only* or *Internal Network*), never your campus or home LAN.
* Do not commit raw captures that contain real personal data or credentials. Use lab-only accounts.
* Follow your course's ethical scope: no unauthorised scanning, exploitation, credential attacks or DoS outside the lab.

## 2. Suggested lab
| VM | Role | Notes |
|---|---|---|
| Kali Linux (or Ubuntu) | "Attacker"/analyst workstation | Wireshark, nmap, tcpdump preinstalled on Kali |
| Metasploitable 2 / DVWA / OWASP Juice Shop | Intentionally vulnerable target | Offers FTP, Telnet, HTTP in cleartext |
| Optional Ubuntu client | Normal user traffic | Browse, ping, DNS lookups |

## 3. Procedure
1. Start Wireshark (or tcpdump) on the host-only interface.
2. Generate **normal** traffic for ~2 minutes: web browsing, DNS lookups, `ping`.
3. Generate **lab activity** against your own target, for example:
   * Host discovery: `nmap -sn 192.168.56.0/24`
   * Port scan: `nmap -sS -p 1-1000 <target-ip>`
   * Cleartext logins: `ftp <target-ip>` and `telnet <target-ip>` with lab credentials
   * Optional (isolated VMs only, instructor permission): ARP spoofing or SYN-flood experiments
4. Stop capture, save as `captures/my_lab.pcapng` (this folder is git-ignored).
5. Analyse: `python -m nta analyze captures/my_lab.pcapng --name my_lab --charts`
6. Verify findings with [WIRESHARK_GUIDE.md](WIRESHARK_GUIDE.md) and add screenshots to `docs/screenshots/`.
7. To publish the sanitised capture, remove the `.gitignore` exception line or `git add -f` that single file.

## 4. What to write up
For each finding: what was observed, evidence (IPs, ports, counts, times), why it matters, MITRE technique,
how you confirmed it in Wireshark, and the fix. Use [FINDINGS_REPORT.md](FINDINGS_REPORT.md) as a template.
