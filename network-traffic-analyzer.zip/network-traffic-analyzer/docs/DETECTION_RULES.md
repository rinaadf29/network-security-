# Detection Rules

Default thresholds are in `nta/analyzer.py::Thresholds`.

| # | Rule (category) | Logic | Default | Severity | MITRE ATT&CK |
|---|---|---|---|---|---|
| 1 | **Port scan** | One source sends bare SYNs (SYN set, ACK clear) to ≥ N distinct ports on one host; ports answering SYN-ACK are listed as open | 15 ports | High | T1046 |
| 1b | **Horizontal scan** | One source SYNs the same port on ≥ N hosts | 10 hosts | Medium | T1046 |
| 2 | **Host sweep** | One source sends ICMP echo requests to ≥ N hosts | 10 hosts | Medium | T1018 |
| 3 | **SYN flood** | ≥ N SYNs to one `host:port` and < 20% completed handshakes; reports peak SYNs/s and unique sources | 100 SYNs | High | T1498 |
| 4 | **Suspicious port** | TCP/UDP to a port on the watch-list (4444, 31337, 1337, 12345, 6667, 5555, 9001, 2323, 1080 ...). Data exchanged = High; attempts only = Low | list | High / Low | T1571 |
| 5 | **Beaconing** | ≥ N new connections from one host to one `dst:port` with interval coefficient of variation (stdev/mean) ≤ 0.2 and mean ≥ 1 s. High if port is on the watch-list | 8 events | Medium / High | T1071 |
| 6 | **DNS tunneling** | ≥ 10 queries from one client to sub-domains of one parent domain with ≥ 15 unique sub-domains or average length ≥ 30 chars; entropy reported | see left | High | T1071.004 |
| 7 | **DNS anomaly** | ≥ N NXDOMAIN responses to one client | 10 | Medium | T1568.002 |
| 8 | **ARP spoofing** | One IP address announced by more than one MAC in ARP traffic | 2 MACs | High | T1557.002 |
| 9 | **Cleartext protocol** | Telnet (High), FTP, HTTP, POP3, IMAP, SNMP, TFTP, LDAP carrying payload | any | Medium / High | T1040 |
| 9b | **Cleartext credentials** | HTTP Basic auth, HTTP form `user=`/`password=`, FTP/POP3 `USER`/`PASS`; passwords masked | any | High | T1040 |
| 10 | **Large outbound transfer** | Internal → external bytes for one host pair above limit | 5 MB | Medium | T1041 |

## Known false positives and tuning
* **Port scan / sweep** - authorised vulnerability scanners (Nessus, OpenVAS) and monitoring tools. Whitelist by source.
* **SYN flood** - busy public servers behind NAT or load balancers; raise `--syn-flood`.
* **Beaconing** - NTP, health checks, monitoring agents and software updaters are legitimately periodic.
  Check the destination and port before escalating.
* **DNS tunneling** - CDNs and some security products use long random sub-domains; verify the parent domain.
* **ARP** - failover pairs (VRRP/HSRP), VM migrations and NIC teaming can legitimately change a MAC.
* **Cleartext** - may be expected on isolated lab/OT networks, but should still be documented as risk.

## Adding a rule
1. Collect the needed counters in `TrafficAnalyzer._ingest`.
2. Write a `_my_rule(self) -> List[Finding]` method and add it to the tuple in `analyze()`.
3. Add a scenario to `nta/sample_gen.py` and an assertion to `tests/test_nta.py`.
