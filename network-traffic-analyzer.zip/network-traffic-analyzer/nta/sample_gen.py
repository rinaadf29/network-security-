"""Deterministic generator for a SYNTHETIC demo capture.

Everything here is fabricated for education: private RFC 1918 addresses for the
lab LAN and RFC 5737 documentation addresses (198.51.100.0/24, 203.0.113.0/24)
for "internet" hosts. No real traffic, hosts or credentials are involved.
"""
from __future__ import annotations

import base64
import random
import socket
import struct
from typing import List, Tuple

FIN, SYN, RST, PSH, ACK = 0x01, 0x02, 0x04, 0x08, 0x10
Frame = Tuple[float, bytes]

GW, WS1, WS2, WS3, SRV, ATT = ("192.168.1.1", "192.168.1.10", "192.168.1.11",
                               "192.168.1.12", "192.168.1.20", "192.168.1.66")
WEB, NTP, C2 = "203.0.113.10", "203.0.113.123", "198.51.100.77"
MACS = {
    GW: "00:11:22:33:44:01", WS1: "52:54:00:aa:00:10", WS2: "52:54:00:aa:00:11",
    WS3: "52:54:00:aa:00:12", SRV: "52:54:00:bb:00:20", ATT: "52:54:00:de:ad:66",
}
BCAST = "ff:ff:ff:ff:ff:ff"


# ------------------------------------------------------------------ builders
def _csum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    s = sum(struct.unpack("!%dH" % (len(data) // 2), data))
    s = (s >> 16) + (s & 0xFFFF)
    s += s >> 16
    return (~s) & 0xFFFF


def _mac(m: str) -> bytes:
    return bytes(int(x, 16) for x in m.split(":"))


def eth(dst: str, src: str, etype: int, payload: bytes) -> bytes:
    return _mac(dst) + _mac(src) + struct.pack("!H", etype) + payload


def ipv4(src, dst, proto, payload, ttl=64, ident=0) -> bytes:
    hdr = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(payload), ident & 0xFFFF,
                      0x4000, ttl, proto, 0, socket.inet_aton(src), socket.inet_aton(dst))
    return hdr[:10] + struct.pack("!H", _csum(hdr)) + hdr[12:] + payload


def tcp(src, dst, sport, dport, seq, ack, flags, payload=b"", mss=False) -> bytes:
    opts = b"\x02\x04\x05\xb4" if mss else b""
    off = ((5 + len(opts) // 4) << 12) | flags
    hdr = struct.pack("!HHIIHHHH", sport, dport, seq & 0xFFFFFFFF, ack & 0xFFFFFFFF,
                      off, 64240, 0, 0) + opts
    pseudo = (socket.inet_aton(src) + socket.inet_aton(dst)
              + struct.pack("!BBH", 0, 6, len(hdr) + len(payload)))
    c = _csum(pseudo + hdr + payload)
    return hdr[:16] + struct.pack("!H", c) + hdr[18:] + payload


def udp(src, dst, sport, dport, payload) -> bytes:
    hdr = struct.pack("!HHHH", sport, dport, 8 + len(payload), 0)
    pseudo = (socket.inet_aton(src) + socket.inet_aton(dst)
              + struct.pack("!BBH", 0, 17, len(hdr) + len(payload)))
    c = _csum(pseudo + hdr + payload) or 0xFFFF
    return hdr[:6] + struct.pack("!H", c) + payload


def icmp(itype, ident, seq, payload=b"") -> bytes:
    hdr = struct.pack("!BBHHH", itype, 0, 0, ident, seq)
    return hdr[:2] + struct.pack("!H", _csum(hdr + payload)) + hdr[4:] + payload


def arp(op, smac, sip, tmac, tip) -> bytes:
    return struct.pack("!HHBBH6s4s6s4s", 1, 0x0800, 6, 4, op, _mac(smac),
                       socket.inet_aton(sip), _mac(tmac), socket.inet_aton(tip))


def _qname(name: str) -> bytes:
    return b"".join(bytes([len(p)]) + p.encode() for p in name.split(".")) + b"\x00"


def dns_query(ident, name) -> bytes:
    return struct.pack("!HHHHHH", ident, 0x0100, 1, 0, 0, 0) + _qname(name) + struct.pack("!HH", 1, 1)


def dns_response(ident, name, ip=None) -> bytes:
    q = _qname(name) + struct.pack("!HH", 1, 1)
    if ip is None:   # NXDOMAIN
        return struct.pack("!HHHHHH", ident, 0x8183, 1, 0, 0, 0) + q
    ans = b"\xc0\x0c" + struct.pack("!HHIH", 1, 1, 300, 4) + socket.inet_aton(ip)
    return struct.pack("!HHHHHH", ident, 0x8180, 1, 1, 0, 0) + q + ans


# ------------------------------------------------------------------ simulator
class Sim:
    def __init__(self, rng: random.Random):
        self.rng = rng
        self.frames: List[Frame] = []
        self._id = 1

    def add(self, ts: float, frame: bytes) -> None:
        self.frames.append((ts, frame))

    def _ident(self) -> int:
        self._id += 1
        return self._id

    @staticmethod
    def mac_of(ip: str) -> str:
        return MACS.get(ip, MACS[GW])

    def send(self, ts, src, dst, proto, l4, ttl=64, eth_src=None, eth_dst=None):
        self.add(ts, eth(eth_dst or self.mac_of(dst), eth_src or self.mac_of(src), 0x0800,
                         ipv4(src, dst, proto, l4, ttl, self._ident())))

    def tcp_send(self, ts, src, dst, sport, dport, seq, ack, flags, payload=b"",
                 mss=False, **kw):
        self.send(ts, src, dst, 6, tcp(src, dst, sport, dport, seq, ack, flags, payload, mss), **kw)

    def udp_send(self, ts, src, dst, sport, dport, payload):
        self.send(ts, src, dst, 17, udp(src, dst, sport, dport, payload))

    def tcp_conn(self, ts, c, s, sport, dport, exchanges=(), rtt=0.02) -> float:
        cs, ss, t = self.rng.getrandbits(32), self.rng.getrandbits(32), ts
        self.tcp_send(t, c, s, sport, dport, cs, 0, SYN, mss=True); t += rtt / 2
        self.tcp_send(t, s, c, dport, sport, ss, cs + 1, SYN | ACK, mss=True); t += rtt / 2
        cs, ss = cs + 1, ss + 1
        self.tcp_send(t, c, s, sport, dport, cs, ss, ACK)
        for who, data in exchanges:
            t += rtt
            if who == "c":
                self.tcp_send(t, c, s, sport, dport, cs, ss, PSH | ACK, data); cs += len(data)
                t += rtt / 2
                self.tcp_send(t, s, c, dport, sport, ss, cs, ACK)
            else:
                self.tcp_send(t, s, c, dport, sport, ss, cs, PSH | ACK, data); ss += len(data)
                t += rtt / 2
                self.tcp_send(t, c, s, sport, dport, cs, ss, ACK)
        t += rtt
        self.tcp_send(t, c, s, sport, dport, cs, ss, FIN | ACK); cs += 1; t += rtt / 2
        self.tcp_send(t, s, c, dport, sport, ss, cs, FIN | ACK); ss += 1; t += rtt / 2
        self.tcp_send(t, c, s, sport, dport, cs, ss, ACK)
        return t

    def rand_bytes(self, n: int) -> bytes:
        return bytes(self.rng.getrandbits(8) for _ in range(n))

    def sport(self) -> int:
        return self.rng.randint(49152, 65000)


# ------------------------------------------------------------------ scenarios
def _baseline(sim: Sim, t0: float) -> None:
    rng, ws = sim.rng, [WS1, WS2, WS3]
    for i, w in enumerate(ws):                                   # ARP: who has gateway?
        t = t0 + 0.1 + i * 0.3
        sim.add(t, eth(BCAST, MACS[w], 0x0806, arp(1, MACS[w], w, "00:00:00:00:00:00", GW)))
        sim.add(t + 0.001, eth(MACS[w], MACS[GW], 0x0806, arp(2, MACS[GW], GW, MACS[w], w)))
    domains = ["www.example.com", "en.wikipedia.org", "mail.example.org",
               "cdn.example.net", "updates.example.com", "api.example.org"]
    for w in ws:                                                 # normal DNS
        for _ in range(8):
            t, name, sp, ident = t0 + 2 + rng.random() * 280, rng.choice(domains), sim.sport(), rng.getrandbits(16)
            sim.udp_send(t, w, GW, sp, 53, dns_query(ident, name))
            sim.udp_send(t + 0.02, GW, w, 53, sp, dns_response(ident, name, f"203.0.113.{rng.randint(20, 90)}"))
    for w in ws:                                                 # HTTPS to a web server
        for _ in range(5):
            hello = b"\x16\x03\x01\x02\x00\x01\x00\x01\xfc\x03\x03" + sim.rand_bytes(180)
            shello = b"\x16\x03\x03\x00\x7a\x02\x00\x00\x76\x03\x03" + sim.rand_bytes(300)
            data1 = b"\x17\x03\x03" + sim.rand_bytes(400)
            data2 = b"\x17\x03\x03" + sim.rand_bytes(900)
            sim.tcp_conn(t0 + 5 + rng.random() * 270, w, WEB, sim.sport(), 443,
                         [("c", hello), ("s", shello), ("c", data1), ("s", data2)])
    for i in range(4):                                           # plain HTTP, no credentials
        req = b"GET /index.html HTTP/1.1\r\nHost: 192.168.1.20\r\nUser-Agent: Mozilla/5.0\r\n\r\n"
        body = b"<html><body>Welcome to the intranet</body></html>"
        resp = b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: %d\r\n\r\n" % len(body) + body
        sim.tcp_conn(t0 + 12 + i * 50 + rng.random() * 5, WS1, SRV, sim.sport(), 80, [("c", req), ("s", resp)])
    for i in range(6):                                           # NTP
        t, sp = t0 + 3 + i * 45, sim.sport()
        sim.udp_send(t, WS2, NTP, sp, 123, b"\x1b" + b"\x00" * 47)
        sim.udp_send(t + 0.03, NTP, WS2, 123, sp, b"\x1c" + sim.rand_bytes(47))
    for i in range(4):                                           # ping gateway
        t = t0 + 8 + i
        sim.send(t, WS3, GW, 1, icmp(8, 0x1234, i, b"abcdefghijklmnopqrstuvwabcdefghi"))
        sim.send(t + 0.002, GW, WS3, 1, icmp(0, 0x1234, i, b"abcdefghijklmnopqrstuvwabcdefghi"))


def _insecure_services(sim: Sim, t0: float) -> None:
    creds = base64.b64encode(b"student:labpass123").decode()
    req = (b"GET /admin HTTP/1.1\r\nHost: 192.168.1.20\r\nAuthorization: Basic "
           + creds.encode() + b"\r\nUser-Agent: Mozilla/5.0\r\n\r\n")
    body = b"<html><body>Admin panel</body></html>"
    resp = b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: %d\r\n\r\n" % len(body) + body
    sim.tcp_conn(t0 + 18, WS2, SRV, sim.sport(), 80, [("c", req), ("s", resp)])
    ftp = [("s", b"220 FTP server ready\r\n"), ("c", b"USER student\r\n"),
           ("s", b"331 Password required\r\n"), ("c", b"PASS ftp_lab_pw\r\n"),
           ("s", b"230 Login successful\r\n"), ("c", b"QUIT\r\n"), ("s", b"221 Goodbye\r\n")]
    sim.tcp_conn(t0 + 22, WS2, SRV, sim.sport(), 21, ftp)
    tel = [("s", b"login: "), ("c", b"admin\r\n"), ("s", b"Password: "),
           ("c", b"labpass\r\n"), ("s", b"Welcome\r\n$ "), ("c", b"ls\r\n"), ("s", b"notes.txt\r\n$ ")]
    sim.tcp_conn(t0 + 26, WS3, SRV, sim.sport(), 23, tel)


def _attacks(sim: Sim, t0: float) -> None:
    rng = sim.rng
    # 1) ICMP ping sweep of the /24 (first 30 hosts)
    for i in range(1, 31):
        ip, t = f"192.168.1.{i}", t0 + 30 + i * 0.05
        sim.send(t, ATT, ip, 1, icmp(8, 0x4242, i, b"\x00" * 32),
                 eth_dst=None if ip in MACS else BCAST)
        if ip in MACS:
            sim.send(t + 0.001, ip, ATT, 1, icmp(0, 0x4242, i, b"\x00" * 32))
    # 2) TCP SYN port scan of the server
    ports = list(range(1, 101)) + [111, 135, 139, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080]
    t = t0 + 45
    for p in ports:
        seq = rng.getrandbits(32)
        sim.tcp_send(t, ATT, SRV, 40001, p, seq, 0, SYN, mss=True)
        if p in (21, 22, 23, 80):
            sim.tcp_send(t + 0.001, SRV, ATT, p, 40001, rng.getrandbits(32), seq + 1, SYN | ACK, mss=True)
            sim.tcp_send(t + 0.002, ATT, SRV, 40001, p, seq + 1, 0, RST)
        else:
            sim.tcp_send(t + 0.001, SRV, ATT, p, 40001, 0, seq + 1, RST | ACK)
        t += 0.02
    # 3) C2-style beaconing on TCP/4444 (Metasploit default) every ~30 s
    for i in range(12):
        t = t0 + 10 + i * 30 + rng.uniform(-1, 1)
        sim.tcp_conn(t, WS1, C2, sim.sport(), 4444, [("c", sim.rand_bytes(16)), ("s", sim.rand_bytes(8))])
    # 4) DNS tunnelling to a made-up domain (long, random, NXDOMAIN)
    for i in range(40):
        t, ident, sp = t0 + 90 + i * 0.5, rng.getrandbits(16), sim.sport()
        sub = base64.b32encode(sim.rand_bytes(28)).decode().lower().rstrip("=")
        name = f"{sub}.c2-lab.example"
        sim.udp_send(t, WS3, GW, sp, 53, dns_query(ident, name))
        sim.udp_send(t + 0.03, GW, WS3, 53, sp, dns_response(ident, name, None))
    # 5) ARP spoofing: attacker claims to be the gateway
    for i in range(6):
        t = t0 + 100 + i * 2
        for victim in (WS1, WS2):
            sim.add(t, eth(MACS[victim], MACS[ATT], 0x0806, arp(2, MACS[ATT], GW, MACS[victim], victim)))
    # 6) SYN flood against the web server from spoofed sources
    t = t0 + 150
    for _ in range(300):
        src = f"198.51.100.{rng.randint(2, 250)}"
        sim.tcp_send(t, src, SRV, rng.randint(1024, 65535), 80, rng.getrandbits(32), 0, SYN,
                     mss=True, ttl=rng.randint(40, 120), eth_src=MACS[ATT], eth_dst=MACS[SRV])
        t += 0.01


def build_frames(seed: int = 7, attacks: bool = True) -> List[Frame]:
    sim, t0 = Sim(random.Random(seed)), 1730000000.0
    _baseline(sim, t0)
    if attacks:
        _insecure_services(sim, t0)
        _attacks(sim, t0)
    return sorted(sim.frames, key=lambda f: f[0])


# ------------------------------------------------------------------ writers
def write_pcap(path: str, frames: List[Frame]) -> int:
    with open(path, "wb") as f:
        f.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
        for ts, data in frames:
            sec = int(ts)
            f.write(struct.pack("<IIII", sec, int((ts - sec) * 1e6), len(data), len(data)) + data)
    return len(frames)


def write_pcapng(path: str, frames: List[Frame]) -> int:
    with open(path, "wb") as f:
        f.write(struct.pack("<IIIHHqI", 0x0A0D0D0A, 28, 0x1A2B3C4D, 1, 0, -1, 28))
        f.write(struct.pack("<IIHHII", 1, 20, 1, 0, 65535, 20))
        for ts, data in frames:
            us, pad = int(round(ts * 1e6)), (-len(data)) % 4
            total = 32 + len(data) + pad
            f.write(struct.pack("<IIIIIII", 6, total, 0, us >> 32, us & 0xFFFFFFFF, len(data), len(data)))
            f.write(data + b"\x00" * pad + struct.pack("<I", total))
    return len(frames)


def generate(path: str, seed: int = 7, attacks: bool = True, pcapng: bool = False) -> int:
    frames = build_frames(seed, attacks)
    return (write_pcapng if pcapng else write_pcap)(path, frames)
