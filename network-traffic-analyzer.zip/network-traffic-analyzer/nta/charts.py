"""Optional PNG charts (requires matplotlib)."""
from __future__ import annotations

import os
from typing import List

from .analyzer import AnalysisResult


def make_charts(r: AnalysisResult, out_dir: str, name: str) -> List[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("[!] matplotlib not installed - skipping charts (pip install matplotlib)")
        return []
    os.makedirs(out_dir, exist_ok=True)
    paths = []

    def save(fig, suffix):
        p = os.path.join(out_dir, f"{name}_{suffix}.png")
        fig.tight_layout()
        fig.savefig(p, dpi=130)
        plt.close(fig)
        paths.append(p)

    fig, ax = plt.subplots(figsize=(6, 4))
    names, vals = zip(*r.transport) if r.transport else ((), ())
    ax.bar(names, vals, color="#3b82f6")
    ax.set_title("Packets by protocol")
    ax.set_ylabel("Packets")
    save(fig, "protocols")

    if r.applications:
        fig, ax = plt.subplots(figsize=(7, 4))
        top = r.applications[:8]
        ax.barh([a["name"] for a in top][::-1], [a["packets"] for a in top][::-1], color="#10b981")
        ax.set_title("Application-layer protocols (packets)")
        save(fig, "applications")

    if r.top_talkers:
        fig, ax = plt.subplots(figsize=(7, 4))
        top = r.top_talkers[:8]
        ax.barh([t["ip"] for t in top][::-1], [t["bytes"] / 1024 for t in top][::-1], color="#f59e0b")
        ax.set_title("Top talkers (KB sent)")
        save(fig, "top_talkers")

    if r.timeline:
        fig, ax = plt.subplots(figsize=(8, 3.5))
        ax.plot([t["t"] for t in r.timeline], [t["packets"] for t in r.timeline], color="#ef4444")
        ax.fill_between([t["t"] for t in r.timeline], [t["packets"] for t in r.timeline],
                        color="#ef4444", alpha=0.15)
        ax.set_title("Traffic over time")
        ax.set_xlabel("Seconds since capture start")
        ax.set_ylabel("Packets per bucket")
        save(fig, "timeline")
    return paths
