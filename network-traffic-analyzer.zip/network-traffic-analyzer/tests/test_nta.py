import os
import tempfile
import unittest
from collections import Counter

from nta import cli
from nta.analyzer import TrafficAnalyzer, Thresholds, entropy, extract_credentials, is_internal
from nta.pcap_reader import Packet, iter_packets, parse_dns
from nta.report import render_json, render_markdown
from nta.sample_gen import dns_query, generate


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        d = cls.tmp.name
        cls.full = os.path.join(d, "full.pcap")
        cls.ng = os.path.join(d, "full.pcapng")
        cls.base = os.path.join(d, "base.pcap")
        generate(cls.full)
        generate(cls.ng, pcapng=True)
        generate(cls.base, attacks=False)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def analyze(self, path):
        return TrafficAnalyzer().analyze(iter_packets(path), os.path.basename(path))


class TestReader(Base):
    def test_pcap_and_pcapng_agree(self):
        a = Counter(p.proto for p in iter_packets(self.full))
        b = Counter(p.proto for p in iter_packets(self.ng))
        self.assertEqual(a, b)
        self.assertGreater(sum(a.values()), 1000)

    def test_rejects_non_pcap(self):
        bad = os.path.join(self.tmp.name, "bad.pcap")
        with open(bad, "wb") as fh:
            fh.write(b"not a capture file at all")
        with self.assertRaises(ValueError):
            list(iter_packets(bad))

    def test_dns_parser(self):
        self.assertEqual(parse_dns(dns_query(1, "WWW.Example.com"))[0], "www.example.com")
        self.assertIsNone(parse_dns(b"\x00" * 5))


class TestDetections(Base):
    def test_all_expected_categories_in_sample(self):
        cats = {f.category for f in self.analyze(self.full).findings}
        for expected in ("Port Scan", "Host Sweep", "SYN Flood", "Suspicious Port", "Beaconing",
                         "DNS Tunneling", "DNS Anomaly", "ARP Spoofing", "Cleartext Protocol",
                         "Cleartext Credentials"):
            self.assertIn(expected, cats)

    def test_pcapng_gives_same_findings(self):
        a = [f.title for f in self.analyze(self.full).findings]
        b = [f.title for f in self.analyze(self.ng).findings]
        self.assertEqual(sorted(a), sorted(b))

    def test_benign_traffic_has_no_high_findings(self):
        r = self.analyze(self.base)
        self.assertEqual([f for f in r.findings if f.severity in ("Critical", "High")], [])

    def test_scan_names_attacker_and_open_ports(self):
        scan = next(f for f in self.analyze(self.full).findings if f.category == "Port Scan")
        self.assertIn("192.168.1.66", scan.title)
        self.assertIn("21, 22, 23, 80", " ".join(scan.evidence))

    def test_thresholds_are_respected(self):
        r = TrafficAnalyzer(Thresholds(scan_ports=500)).analyze(iter_packets(self.full))
        self.assertNotIn("Port Scan", {f.category for f in r.findings})

    def test_passwords_never_appear_in_reports(self):
        r = self.analyze(self.full)
        text = render_markdown(r) + render_json(r)
        for secret in ("labpass123", "ftp_lab_pw", "labpass\\r"):
            self.assertNotIn(secret, text)


class TestHelpers(unittest.TestCase):
    def test_is_internal(self):
        self.assertTrue(is_internal("192.168.1.5"))
        self.assertTrue(is_internal("10.2.3.4"))
        self.assertFalse(is_internal("203.0.113.9"))   # documentation range is NOT internal

    def test_entropy(self):
        self.assertGreater(entropy("a3f9x0qzp1"), entropy("aaaaaaaaaa"))

    def test_extract_http_basic_credentials(self):
        p = Packet(ts=0, length=0, proto="TCP", app="HTTP",
                   payload=b"GET / HTTP/1.1\r\nAuthorization: Basic dXNlcjpzZWNyZXQ=\r\n\r\n")
        creds = extract_credentials(p)
        self.assertIn(("HTTP Basic Auth", "user", "user"), creds)
        self.assertIn(("HTTP Basic Auth", "password", "s*****"), creds)


class TestCLI(Base):
    def test_fail_on_exit_code(self):
        out = os.path.join(self.tmp.name, "out")
        self.assertEqual(cli.main(["analyze", self.full, "-o", out, "--fail-on", "High"]), 2)
        self.assertEqual(cli.main(["analyze", self.base, "-o", out, "--fail-on", "High"]), 0)
        self.assertTrue(os.path.exists(os.path.join(out, "full_report.md")))


if __name__ == "__main__":
    unittest.main()
