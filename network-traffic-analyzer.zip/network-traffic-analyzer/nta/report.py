"""Render AnalysisResult as Markdown / JSON / console text."""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone

from .analyzer import SEVERITIES, AnalysisResult

_ICON = {"Critical": "🟣", "High": "🔴", "Medium": "🟠", "Low": "🟡", "Info": "🔵"}


def _bar(value: int, total: int, width: int = 20) -> str:
    return "█" * max(1, round(width * value / total)) if total and value else ""


def _human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return str(n)


def render_markdown(r: AnalysisResult) -> str:
    s, L = r.summary, []
    sev = s["findings"]
    L += ["# Network Traffic Analysis Report", "",
          f"**Capture file:** `{s['file']}`  ", f"**Report generated:** "
          f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}  ",
          "**Tool:** Network Traffic Analyzer (NTA)", "",
          "## 1. Executive Summary", ""]
    total = sum(sev.values())
    if total:
        L.append(f"The capture contains **{s['packets']:,} packets** over **{s['duration_s']:.0f} s** "
                 f"between **{s['unique_hosts']} hosts**. The analysis raised **{total} findings**, "
                 f"including **{sev['Critical'] + sev['High']} high-priority** items that should be "
                 "triaged first.")
    else:
        L.append(f"The capture contains {s['packets']:,} packets and no suspicious patterns were detected "
                 "with the configured thresholds.")
    L += ["", "| Severity | Findings |", "|---|---|"]
    L += [f"| {_ICON[k]} {k} | {sev[k]} |" for k in SEVERITIES]
    if r.findings:
        L += ["", "**Key findings:**", ""]
        L += [f"- {_ICON[f.severity]} **{f.category}** - {f.title}" for f in r.findings if f.severity in ("Critical", "High")]
    L += ["", "## 2. Capture Overview", "", "| Metric | Value |", "|---|---|",
          f"| Packets | {s['packets']:,} |", f"| Total size | {_human(s['bytes'])} |",
          f"| Start / End | {s['start']} / {s['end']} |", f"| Duration | {s['duration_s']} s |",
          f"| Average rate | {s['avg_pps']} packets/s |",
          f"| Average packet size | {s['avg_packet_bytes']} bytes |",
          f"| Unique IP hosts | {s['unique_hosts']} ({s['internal_hosts']} internal) |", ""]

    L += ["## 3. Protocol Distribution", "", "**Transport / network layer**", "",
          "| Protocol | Packets | Share | |", "|---|---:|---:|---|"]
    for name, n in r.transport:
        L.append(f"| {name} | {n:,} | {n / s['packets']:.1%} | {_bar(n, s['packets'])} |")
    L += ["", "**Application layer (TCP/UDP)**", "", "| Application | Packets | Bytes |", "|---|---:|---:|"]
    L += [f"| {a['name']} | {a['packets']:,} | {_human(a['bytes'])} |" for a in r.applications]

    L += ["", "## 4. Top Talkers and Conversations", "", "| Host | Scope | Packets sent | Bytes sent |",
          "|---|---|---:|---:|"]
    L += [f"| `{t['ip']}` | {'internal' if t['internal'] else 'external'} | {t['packets']:,} | {_human(t['bytes'])} |"
          for t in r.top_talkers]
    L += ["", "| Host A | Host B | Packets | Bytes |", "|---|---|---:|---:|"]
    L += [f"| `{c['a']}` | `{c['b']}` | {c['packets']:,} | {_human(c['bytes'])} |" for c in r.top_conversations]

    L += ["", "## 5. Port Analysis (by destination port)", "",
          "| Proto | Port | Service | Packets | Note |", "|---|---:|---|---:|---|"]
    for p in r.top_ports:
        note = {"suspicious": "⚠️ suspicious port", "cleartext": "🔓 cleartext protocol"}.get(p["note"], "")
        L.append(f"| {p['proto']} | {p['port']} | {p['service'] or '-'} | {p['packets']:,} | {note} |")

    L += ["", "## 6. Detailed Findings", ""]
    if not r.findings:
        L.append("_No findings._")
    for i, f in enumerate(r.findings, 1):
        L += [f"### F-{i:02d} {_ICON[f.severity]} [{f.severity}] {f.title}", "",
              f"- **Category:** {f.category}"]
        if f.mitre:
            L.append(f"- **MITRE ATT&CK:** {f.mitre}")
        L += ["", f.description, "", "**Evidence**", ""]
        L += [f"- {e}" for e in f.evidence]
        L += ["", f"**Recommendation:** {f.recommendation}", ""]

    L += ["## 7. Method and Limitations", "",
          "Packets were decoded offline from the capture file and aggregated per host, port, flow "
          "and protocol. Detections are **heuristics**: thresholds are listed below and can be tuned. "
          "A finding is an *indicator to investigate*, not proof of compromise, and legitimate "
          "scanners, backup jobs or monitoring tools can look similar. Encrypted payloads (TLS/SSH) "
          "cannot be inspected beyond metadata. Passwords are masked in this report.", "",
          "| Threshold | Value |", "|---|---|"]
    L += [f"| `{k}` | {v} |" for k, v in r.thresholds.items()]
    return "\n".join(L) + "\n"


def render_json(r: AnalysisResult) -> str:
    return json.dumps(r.to_dict(), indent=2)


def console_summary(r: AnalysisResult) -> str:
    s = r.summary
    out = [f"File     : {s['file']}",
           f"Packets  : {s['packets']:,}  ({_human(s['bytes'])}, {s['duration_s']} s, {s['unique_hosts']} hosts)",
           "Findings : " + ("  ".join(f"{k}={v}" for k, v in s["findings"].items() if v) or "none"), ""]
    for f in r.findings:
        out.append(f"[{f.severity:<8}] {f.category:<20} {f.title}")
    return "\n".join(out)


def write_reports(r: AnalysisResult, out_dir: str, name: str, formats=("md", "json"), charts=False):
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    if "md" in formats:
        p = os.path.join(out_dir, f"{name}_report.md")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(render_markdown(r))
        paths.append(p)
    if "json" in formats:
        p = os.path.join(out_dir, f"{name}_report.json")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(render_json(r))
        paths.append(p)
    if charts:
        from .charts import make_charts
        paths += make_charts(r, os.path.join(out_dir, "charts"), name)
    return paths
