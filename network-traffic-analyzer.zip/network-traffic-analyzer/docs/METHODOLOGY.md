# Methodology

## 1. Objective
Turn raw packet captures into prioritised, evidence-backed security findings, the same workflow a SOC analyst
or network security engineer follows when triaging suspicious network activity.

## 2. Workflow

| Stage | Activity | Tool |
|---|---|---|
| Collect | Capture traffic on an authorised network/lab | Wireshark, tcpdump, tshark, Scapy (`nta capture`) |
| Decode | Parse link, network, transport and application layers | `nta/pcap_reader.py` |
| Baseline | Establish what normal looks like (protocols, top talkers, ports) | `nta` statistics + Wireshark *Statistics* menu |
| Detect | Apply heuristic rules to find anomalies | `nta/analyzer.py` |
| Validate | Confirm each finding manually in Wireshark/tshark | [WIRESHARK_GUIDE.md](WIRESHARK_GUIDE.md) |
| Report | Document evidence, impact, MITRE mapping and fixes | `nta/report.py`, [FINDINGS_REPORT.md](FINDINGS_REPORT.md) |

## 3. Decoding
Supported capture formats: libpcap (micro/nanosecond, both byte orders) and pcapng (SHB/IDB/EPB/SPB blocks,
per-interface timestamp resolution). Link types: Ethernet (with 802.1Q/ad VLAN tags), Linux cooked (SLL),
raw IP. Payloads are trimmed to the IP total length so Ethernet padding is not counted as data.
Application protocol is chosen by payload signature first (HTTP verbs, TLS record header, DNS message) and by
well-known port second, so services on non-standard ports are still labelled.

## 4. Statistics collected
Packets/bytes, duration and rate, protocol and application mix, bytes per source, conversations (unordered host
pairs), destination-port popularity, per-second timeline, and internal/external host split (RFC 1918, link-local,
loopback and multicast count as internal; documentation ranges do not).

## 5. Detection philosophy
* **Few, explainable rules** - each rule maps to a recognised attacker behaviour and a MITRE ATT&CK technique.
* **Evidence first** - every finding carries concrete numbers (hosts, ports, counts, timestamps).
* **Tunable** - thresholds live in `Thresholds` and can be changed on the command line.
* **Honest about uncertainty** - findings are indicators, and the report states limitations.
* **Privacy-aware** - passwords are masked at extraction time and never stored in results.

See [DETECTION_RULES.md](DETECTION_RULES.md) for each rule's logic and false-positive notes.

## 6. Validation approach
Unit tests generate a deterministic synthetic capture (`nta/sample_gen.py`) and assert that: all embedded
attacks are detected; a benign-only capture yields no High/Critical findings; pcap and pcapng give identical
results; thresholds are honoured; and secrets never reach reports.
