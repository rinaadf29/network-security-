"""Network Traffic Analyzer (NTA) - offline PCAP analysis for suspicious activity."""
__version__ = "1.0.0"
