"""Traffic statistics and heuristic detections over decoded packets."""
from __future__ import annotations

import base64
import ipaddress
import math
import re
import statistics
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional

from .pcap_reader import (ACK, CLEARTEXT_APPS, FIN, RST, SYN, Packet, service_name)

SEVERITIES = ["Critical", "High", "Medium", "Low", "Info"]

SUSPICIOUS_PORTS = {
    4444: "Metasploit default handler / common reverse shell",
    31337: "Back Orifice / 'elite' backdoor port",
    1337: "Common backdoor / hacker-culture port",
    12345: "NetBus trojan",
    54321: "Back Orifice 2000 / reverse shells",
    6667: "IRC (classic botnet command & control)",
    6666: "IRC alt / backdoors",
    5555: "Android ADB / remote-access tools",
    9001: "Tor relay (OR) default port",
    2323: "Telnet alternate (Mirai-style IoT botnets)",
    1080: "SOCKS proxy (tunnelling)",
    7777: "Common RAT / game-server port abused by malware",
}

_INTERNAL = [ipaddress.ip_network(n) for n in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16",
    "127.0.0.0/8", "224.0.0.0/4", "255.255.255.255/32")]

_REC = {
    "Telnet": "Replace Telnet with SSH and disable the Telnet service.",
    "FTP": "Replace FTP with SFTP or FTPS and disable anonymous/clear logins.",
    "HTTP": "Serve the site over HTTPS (TLS), redirect HTTP to HTTPS and enable HSTS.",
    "POP3": "Use POP3S/IMAPS (TLS) or modern authenticated mail submission.",
    "IMAP": "Use IMAPS (TLS) and disable plaintext IMAP.",
    "SNMP": "Move to SNMPv3 with authentication and encryption; restrict by ACL.",
    "TFTP": "Avoid TFTP; if required, isolate it on a management VLAN.",
    "LDAP": "Use LDAPS or StartTLS for directory traffic.",
}


def is_internal(ip: Optional[str]) -> bool:
    if not ip:
        return False
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if a.version == 6:
        return a.is_private or a.is_link_local or a.is_loopback or a.is_multicast
    return any(a in n for n in _INTERNAL)


def entropy(s: str) -> float:
    if not s:
        return 0.0
    c = Counter(s)
    return -sum(v / len(s) * math.log2(v / len(s)) for v in c.values())


def fmt_ts(ts: float) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def _mask(s: str) -> str:
    return "*" if len(s) <= 1 else s[0] + "*" * min(len(s) - 1, 8)


def _cap(lines: List[str], n: int = 10) -> List[str]:
    return lines if len(lines) <= n else lines[:n] + [f"... and {len(lines) - n} more"]


@dataclass
class Finding:
    severity: str
    category: str
    title: str
    description: str
    evidence: List[str] = field(default_factory=list)
    recommendation: str = ""
    mitre: str = ""


@dataclass
class Thresholds:
    scan_ports: int = 15            # distinct ports from one source to one host
    sweep_hosts: int = 10           # distinct hosts probed by one source
    syn_flood_syns: int = 100       # SYNs to one service ...
    syn_flood_completion: float = 0.2   # ... with < this share completing
    beacon_min_events: int = 8
    beacon_max_cv: float = 0.2      # stdev/mean of connection intervals
    beacon_min_interval: float = 1.0
    dns_unique_subdomains: int = 15
    dns_long_label: int = 30
    nxdomain_min: int = 10
    exfil_bytes: int = 5_000_000


@dataclass
class AnalysisResult:
    source: str
    summary: dict
    transport: list
    applications: list
    top_talkers: list
    top_conversations: list
    top_ports: list
    timeline: list
    findings: List[Finding]
    thresholds: dict

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------- credentials
_HTTP_AUTH = re.compile(r"(?im)^authorization:\s*basic\s+([A-Za-z0-9+/=]+)")
_FORM_USER = re.compile(r"(?i)\b(?:user(?:name)?|login|email)=([^&\s]+)")
_FORM_PASS = re.compile(r"(?i)\b(?:pass(?:word|wd)?|pwd)=([^&\s]+)")
_LINE_USER = re.compile(r"(?im)^USER\s+(\S+)")
_LINE_PASS = re.compile(r"(?im)^PASS\s+(\S+)")


def extract_credentials(p: Packet) -> List[tuple]:
    """Return [(kind, field, value)]; passwords are masked immediately."""
    out: List[tuple] = []
    if p.proto != "TCP" or not p.payload:
        return out
    text = p.payload[:2048].decode("latin-1")
    if p.app == "HTTP":
        m = _HTTP_AUTH.search(text)
        if m:
            try:
                user, _, pw = base64.b64decode(m.group(1)).decode("utf-8", "replace").partition(":")
                out += [("HTTP Basic Auth", "user", user), ("HTTP Basic Auth", "password", _mask(pw))]
            except Exception:
                pass
        if text.startswith("POST"):
            body = text.partition("\r\n\r\n")[2]
            u, pw = _FORM_USER.search(body), _FORM_PASS.search(body)
            if pw:
                if u:
                    out.append(("HTTP form login", "user", u.group(1)))
                out.append(("HTTP form login", "password", _mask(pw.group(1))))
    elif p.app in ("FTP", "POP3"):
        u, pw = _LINE_USER.search(text), _LINE_PASS.search(text)
        if u:
            out.append((p.app, "user", u.group(1)))
        if pw:
            out.append((p.app, "password", _mask(pw.group(1))))
    return out


# ---------------------------------------------------------------- analyzer
class TrafficAnalyzer:
    def __init__(self, thresholds: Optional[Thresholds] = None):
        self.th = thresholds or Thresholds()

    def _reset(self) -> None:
        self.n = self.bytes = 0
        self.first_ts = self.last_ts = None
        self.per_second: Counter = Counter()
        self.transport: Counter = Counter()
        self.app_pkts: Counter = Counter()
        self.app_bytes: Counter = Counter()
        self.ip_pkts: Counter = Counter()
        self.ip_bytes: Counter = Counter()
        self.conv: Dict[tuple, List[int]] = defaultdict(lambda: [0, 0])
        self.ports: Counter = Counter()
        self.hosts: set = set()
        self.syns: List[tuple] = []
        self.synacks: set = set()
        self.completions: Counter = Counter()
        self.echo: Dict[str, Dict[str, float]] = defaultdict(dict)
        self.arp: Dict[str, Counter] = defaultdict(Counter)
        self.dns_q: List[tuple] = []
        self.nxdomain: Counter = Counter()
        self.cleartext: Dict[str, Counter] = defaultdict(Counter)
        self.creds: Dict[tuple, dict] = defaultdict(dict)
        self.susp: Dict[tuple, list] = {}
        self.outbound: Counter = Counter()

    # ----------------------------------------------------------- ingestion
    def _ingest(self, p: Packet) -> None:
        self.n += 1
        self.bytes += p.length
        self.first_ts = p.ts if self.first_ts is None else min(self.first_ts, p.ts)
        self.last_ts = p.ts if self.last_ts is None else max(self.last_ts, p.ts)
        self.per_second[int(p.ts)] += 1
        self.transport[p.proto] += 1

        if p.proto == "ARP":
            if p.arp_sender_ip and p.arp_sender_ip != "0.0.0.0":
                self.arp[p.arp_sender_ip][p.arp_sender_mac] += 1
            return
        if not p.src_ip:
            return

        s, d = p.src_ip, p.dst_ip
        self.hosts.update((s, d))
        self.ip_pkts[s] += 1
        self.ip_bytes[s] += p.length
        c = self.conv[tuple(sorted((s, d)))]
        c[0] += 1
        c[1] += p.length
        if is_internal(s) and not is_internal(d):
            self.outbound[(s, d)] += p.length

        if p.proto == "ICMP" and p.icmp_type == 8:
            self.echo[s].setdefault(d, p.ts)
        if p.proto not in ("TCP", "UDP"):
            return

        app = p.app or "Other"
        self.app_pkts[app] += 1
        self.app_bytes[app] += p.length
        self.ports[(p.proto, p.dst_port)] += 1

        if p.proto == "TCP":
            f = p.tcp_flags or 0
            sa = f & (SYN | ACK)
            if sa == SYN and not f & RST:
                self.syns.append((p.ts, s, d, p.src_port, p.dst_port))
            elif sa == SYN | ACK:
                self.synacks.add((s, p.src_port, d))
            elif f & ACK and not f & (SYN | FIN | RST) and not p.payload:
                self.completions[(d, p.dst_port)] += 1

        if p.dns:
            qname, is_resp, rcode, _ = p.dns
            if not is_resp:
                self.dns_q.append((p.ts, s, qname))
            elif rcode == 3:
                self.nxdomain[d] += 1

        if p.dst_port in SUSPICIOUS_PORTS:
            rec = self.susp.setdefault((p.proto, s, d, p.dst_port), [0, 0, 0, p.ts, p.ts])
            rec[0] += 1
            rec[1] += 1 if p.payload else 0
            rec[2] += p.length
            rec[4] = p.ts

        if app in CLEARTEXT_APPS and p.payload:
            sp = p.dst_port if service_name(p.dst_port) else (
                p.src_port if service_name(p.src_port) else min(p.src_port, p.dst_port))
            a, b = sorted((s, d))
            self.cleartext[app][(a, b, sp)] += 1
            for kind, fld, val in extract_credentials(p):
                client, server = (s, d) if p.dst_port == sp else (d, s)
                self.creds[(kind, client, server)][fld] = val

    # ----------------------------------------------------------- driver
    def analyze(self, packets: Iterable[Packet], source: str = "") -> AnalysisResult:
        self._reset()
        for p in packets:
            self._ingest(p)
        findings: List[Finding] = []
        for fn in (self._port_scans, self._ping_sweeps, self._syn_floods, self._suspicious_ports,
                   self._beaconing, self._dns, self._arp_spoofing, self._cleartext, self._exfil):
            findings.extend(fn())
        order = {s: i for i, s in enumerate(SEVERITIES)}
        findings.sort(key=lambda f: order[f.severity])
        return self._build(source, findings)

    # ----------------------------------------------------------- detections
    def _port_scans(self) -> List[Finding]:
        th, out = self.th, []
        by_pair: Dict[tuple, Dict[int, float]] = defaultdict(dict)
        by_port: Dict[tuple, Dict[str, float]] = defaultdict(dict)
        for ts, s, d, _sp, dp in self.syns:
            by_pair[(s, d)].setdefault(dp, ts)
            by_port[(s, dp)].setdefault(d, ts)
        for (s, d), ports in by_pair.items():
            if len(ports) < th.scan_ports:
                continue
            dur = max(max(ports.values()) - min(ports.values()), 0.001)
            open_p = [p for p in sorted(ports) if (d, p, s) in self.synacks]
            out.append(Finding(
                "High", "Port Scan", f"TCP SYN port scan: {s} -> {d}",
                f"{s} sent bare SYN packets to {len(ports)} different TCP ports on {d} in "
                f"{dur:.1f}s ({len(ports) / dur:.0f} ports/s). Probing many ports quickly "
                "is the signature of reconnaissance tools such as Nmap.",
                [f"Source: {s}   Target: {d}",
                 f"Distinct ports probed: {len(ports)} (first seen {fmt_ts(min(ports.values()))})",
                 f"Ports that answered SYN-ACK (open): {', '.join(map(str, open_p)) or 'none'}"],
                "Block or rate-limit the source, enable IDS port-scan rules, and close unused "
                "services on the target. Investigate how the source host got on the network.",
                "T1046 Network Service Discovery"))
        for (s, dp), hosts in by_port.items():
            if len(hosts) >= th.sweep_hosts:
                out.append(Finding(
                    "Medium", "Port Scan", f"Horizontal scan of TCP/{dp} from {s}",
                    f"{s} probed TCP port {dp} on {len(hosts)} different hosts, which looks like a "
                    "search for machines running one specific service.",
                    [f"Source: {s}   Port: {dp} ({service_name(dp) or 'unknown'})",
                     f"Hosts probed: {len(hosts)}"],
                    "Investigate the source and restrict lateral reachability with segmentation.",
                    "T1046 Network Service Discovery"))
        return out

    def _ping_sweeps(self) -> List[Finding]:
        out = []
        for s, targets in self.echo.items():
            if len(targets) >= self.th.sweep_hosts:
                ts = list(targets.values())
                out.append(Finding(
                    "Medium", "Host Sweep", f"ICMP ping sweep from {s}",
                    f"{s} sent ICMP echo requests to {len(targets)} distinct hosts "
                    f"between {fmt_ts(min(ts))} and {fmt_ts(max(ts))}. Sweeps map which hosts are alive.",
                    [f"Source: {s}", f"Distinct hosts pinged: {len(targets)}"],
                    "Confirm whether this is an authorised scanner; otherwise isolate the host. "
                    "Consider rate-limiting ICMP between user segments.",
                    "T1018 Remote System Discovery"))
        return out

    def _syn_floods(self) -> List[Finding]:
        th, out = self.th, []
        groups: Dict[tuple, list] = defaultdict(list)
        for ts, s, d, sp, dp in self.syns:
            groups[(d, dp)].append((ts, s))
        for (d, dp), ev in groups.items():
            if len(ev) < th.syn_flood_syns:
                continue
            done = self.completions.get((d, dp), 0)
            ratio = done / len(ev)
            if ratio >= th.syn_flood_completion:
                continue
            ts = [e[0] for e in ev]
            peak = max(Counter(int(t) for t in ts).values())
            out.append(Finding(
                "High", "SYN Flood", f"Possible SYN flood against {d}:{dp}",
                f"{len(ev)} connection requests (SYN) hit {d}:{dp} (peak {peak}/s) from "
                f"{len({e[1] for e in ev})} source addresses, but only {ratio:.0%} were completed "
                "with a final ACK. Half-open connections exhaust a server's connection table.",
                [f"Target: {d}:{dp} ({service_name(dp) or 'unknown'})",
                 f"SYNs: {len(ev)}   Peak rate: {peak}/s   Unique sources: {len({e[1] for e in ev})}   "
                 f"Handshakes completed (approx.): {done}",
                 f"Window: {fmt_ts(min(ts))} -> {fmt_ts(max(ts))}"],
                "Enable SYN cookies, tune backlog/timeouts, apply upstream rate-limiting or "
                "DDoS protection, and use ingress filtering (BCP 38) against spoofed sources.",
                "T1498 Network Denial of Service"))
        return out

    def _suspicious_ports(self) -> List[Finding]:
        out, attempts = [], []
        for (proto, s, d, dp), (pk, pl, byt, t1, t2) in sorted(self.susp.items()):
            line = f"{s} -> {d}:{dp}/{proto.lower()} ({SUSPICIOUS_PORTS[dp]}): {pk} pkts, {byt} bytes"
            if pl:
                out.append(Finding(
                    "High", "Suspicious Port", f"Data exchanged on suspicious port {dp}: {s} -> {d}",
                    f"{s} exchanged application data with {d} on port {dp}, which is associated with: "
                    f"{SUSPICIOUS_PORTS[dp]}. Legitimate software rarely uses this port.",
                    [line, f"Active {fmt_ts(t1)} -> {fmt_ts(t2)}"],
                    "Identify the process on the internal host owning this connection, block the "
                    "destination at the firewall, and run an endpoint malware scan.",
                    "T1571 Non-Standard Port"))
            else:
                attempts.append(line)
        if attempts:
            out.append(Finding(
                "Low", "Suspicious Port", "Connection attempts to suspicious ports (no data exchanged)",
                "Packets were sent to ports commonly used by backdoors, but no application data followed.",
                _cap(attempts), "Review firewall logs for the sources listed.", "T1571 Non-Standard Port"))
        return out

    def _beaconing(self) -> List[Finding]:
        th, out = self.th, []
        groups: Dict[tuple, List[float]] = defaultdict(list)
        for ts, s, d, _sp, dp in self.syns:
            groups[(s, d, dp)].append(ts)
        for (s, d, dp), ts in groups.items():
            if len(ts) < th.beacon_min_events:
                continue
            ts.sort()
            gaps = [b - a for a, b in zip(ts, ts[1:])]
            mean = statistics.mean(gaps)
            if mean < th.beacon_min_interval:
                continue
            sd = statistics.stdev(gaps)
            if sd / mean <= th.beacon_max_cv:
                sev = "High" if dp in SUSPICIOUS_PORTS else "Medium"
                out.append(Finding(
                    sev, "Beaconing", f"Periodic connections (beaconing): {s} -> {d}:{dp}",
                    f"{s} opened {len(ts)} new connections to {d}:{dp} at an almost constant interval "
                    f"(mean {mean:.1f}s, jitter {sd:.1f}s). Humans do not behave this regularly; "
                    "malware 'check-ins' to a command-and-control server do.",
                    [f"Connections: {len(ts)}   Mean interval: {mean:.1f}s   Std-dev: {sd:.2f}s   "
                     f"CV: {sd / mean:.2f}",
                     f"First: {fmt_ts(ts[0])}   Last: {fmt_ts(ts[-1])}",
                     f"Destination is {'internal' if is_internal(d) else 'external'}"],
                    "Check the destination's reputation, find the originating process, and isolate "
                    "the host if the traffic is not explained by a known application.",
                    "T1071 Application Layer Protocol"))
        return out

    @staticmethod
    def _split_domain(q: str):
        labels = q.split(".")
        k = 3 if len(labels) > 2 and len(labels[-1]) == 2 and labels[-2] in (
            "co", "com", "org", "net", "gov", "ac") else 2
        if len(labels) <= k:
            return q, ""
        return ".".join(labels[-k:]), ".".join(labels[:-k])

    def _dns(self) -> List[Finding]:
        th, out = self.th, []
        groups: Dict[tuple, List[str]] = defaultdict(list)
        for _ts, client, q in self.dns_q:
            parent, sub = self._split_domain(q)
            if sub:
                groups[(client, parent)].append(sub)
        for (client, parent), subs in groups.items():
            uniq = set(subs)
            avg_len = statistics.mean(len(x) for x in subs)
            if len(subs) >= 10 and (len(uniq) >= th.dns_unique_subdomains or avg_len >= th.dns_long_label):
                avg_ent = statistics.mean(entropy(x.replace(".", "")) for x in uniq)
                out.append(Finding(
                    "High", "DNS Tunneling", f"Possible DNS tunneling/exfiltration: {client} -> *.{parent}",
                    f"{client} sent {len(subs)} DNS queries for {len(uniq)} unique, unusually long, "
                    f"high-entropy sub-domains of {parent}. Data can be smuggled out inside DNS "
                    "names, bypassing most firewalls.",
                    [f"Client: {client}   Parent domain: {parent}",
                     f"Queries: {len(subs)}   Unique sub-domains: {len(uniq)}",
                     f"Avg sub-domain length: {avg_len:.0f} chars   Avg entropy: {avg_ent:.2f} bits/char",
                     f"Example: {subs[0][:60]}.{parent}"],
                    "Block the domain, force clients through a monitored resolver, and alert on "
                    "long/high-entropy names and abnormal TXT/NULL query volume.",
                    "T1071.004 Application Layer Protocol: DNS"))
        for client, n in self.nxdomain.items():
            if n >= th.nxdomain_min:
                out.append(Finding(
                    "Medium", "DNS Anomaly", f"Excessive NXDOMAIN replies to {client}",
                    f"{client} received {n} 'domain does not exist' replies. High NXDOMAIN rates "
                    "are typical of DGA malware or DNS tunnelling.",
                    [f"Client: {client}   NXDOMAIN responses: {n}"],
                    "Review the queried names; investigate the host for malware.",
                    "T1568.002 Dynamic Resolution: DGA"))
        return out

    def _arp_spoofing(self) -> List[Finding]:
        out = []
        for ip, macs in self.arp.items():
            if len(macs) > 1:
                out.append(Finding(
                    "High", "ARP Spoofing", f"Multiple MAC addresses claim {ip}",
                    f"Several hardware addresses announced ownership of {ip}. An attacker can "
                    "poison ARP caches this way to become a man-in-the-middle.",
                    [f"{m}: {c} ARP packets" for m, c in macs.most_common()],
                    "Identify the rogue MAC via the switch CAM table, enable Dynamic ARP "
                    "Inspection / port security, and use static ARP entries for critical hosts.",
                    "T1557.002 ARP Cache Poisoning"))
        return out

    def _cleartext(self) -> List[Finding]:
        out = []
        for app, flows in sorted(self.cleartext.items()):
            sev = "High" if app == "Telnet" else "Medium"
            ev = [f"{a} <-> {b} port {p}: {n} data packets" for (a, b, p), n in flows.most_common()]
            out.append(Finding(
                sev, "Cleartext Protocol", f"Unencrypted {app} traffic observed",
                f"{app} carries data without encryption, so anyone on the path can read or alter it.",
                _cap(ev), _REC.get(app, "Use an encrypted alternative."), "T1040 Network Sniffing"))
        if self.creds:
            ev = []
            for (kind, client, server), f in self.creds.items():
                ev.append(f"{kind}: {client} -> {server}  user='{f.get('user', '?')}'  "
                          f"password='{f.get('password', '?')}' (masked)")
            out.append(Finding(
                "High", "Cleartext Credentials", "Credentials sent in cleartext",
                "Usernames and passwords were visible in packet payloads. Anyone capturing this "
                "traffic could reuse them. (Passwords are masked in this report.)",
                _cap(ev), "Rotate the exposed credentials immediately and move the service to an "
                "encrypted protocol with MFA where possible.", "T1040 Network Sniffing"))
        return out

    def _exfil(self) -> List[Finding]:
        out = []
        for (s, d), b in self.outbound.most_common(3):
            if b >= self.th.exfil_bytes:
                out.append(Finding(
                    "Medium", "Data Transfer", f"Large outbound transfer: {s} -> {d}",
                    f"{b / 1e6:.1f} MB left the internal network to an external host.",
                    [f"{s} -> {d}: {b} bytes"], "Verify the transfer is expected (backup, update).",
                    "T1041 Exfiltration Over C2 Channel"))
        return out

    # ----------------------------------------------------------- results
    def _build(self, source: str, findings: List[Finding]) -> AnalysisResult:
        dur = (self.last_ts - self.first_ts) if self.n else 0.0
        counts = Counter(f.severity for f in findings)
        summary = {
            "file": source, "packets": self.n, "bytes": self.bytes, "duration_s": round(dur, 2),
            "start": fmt_ts(self.first_ts) if self.n else "-", "end": fmt_ts(self.last_ts) if self.n else "-",
            "avg_pps": round(self.n / dur, 2) if dur else 0,
            "avg_packet_bytes": round(self.bytes / self.n, 1) if self.n else 0,
            "unique_hosts": len(self.hosts),
            "internal_hosts": sum(1 for h in self.hosts if is_internal(h)),
            "findings": {s: counts.get(s, 0) for s in SEVERITIES},
        }
        apps = [{"name": a, "packets": self.app_pkts[a], "bytes": self.app_bytes[a]}
                for a, _ in self.app_pkts.most_common()]
        talkers = [{"ip": ip, "packets": self.ip_pkts[ip], "bytes": b, "internal": is_internal(ip)}
                   for ip, b in self.ip_bytes.most_common(10)]
        convs = [{"a": k[0], "b": k[1], "packets": v[0], "bytes": v[1]}
                 for k, v in sorted(self.conv.items(), key=lambda kv: -kv[1][1])[:10]]
        ports = []
        for (proto, port), n in self.ports.most_common(15):
            svc = service_name(port)
            note = ("suspicious" if port in SUSPICIOUS_PORTS else
                    "cleartext" if svc in CLEARTEXT_APPS else "")
            ports.append({"proto": proto, "port": port, "service": svc, "packets": n, "note": note})
        timeline = []
        if self.n:
            step = max(1, int(dur // 60) or 1)
            b: Counter = Counter()
            for sec, n in self.per_second.items():
                b[int((sec - int(self.first_ts)) // step)] += n
            timeline = [{"t": k * step, "packets": b.get(k, 0)} for k in range(max(b) + 1)]
        return AnalysisResult(source, summary, self.transport.most_common(), apps, talkers, convs,
                              ports, timeline, findings, asdict(self.th))
