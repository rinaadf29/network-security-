# Network Traffic Analysis Report

**Capture file:** `sample_traffic.pcap`  
**Report generated:** 2026-11-06 06:53 UTC  
**Tool:** Network Traffic Analyzer (NTA)

## 1. Executive Summary

The capture contains **1,151 packets** over **340 s** between **205 hosts**. The analysis raised **12 findings**, including **8 high-priority** items that should be triaged first.

| Severity | Findings |
|---|---|
| 🟣 Critical | 0 |
| 🔴 High | 8 |
| 🟠 Medium | 4 |
| 🟡 Low | 0 |
| 🔵 Info | 0 |

**Key findings:**

- 🔴 **Port Scan** - TCP SYN port scan: 192.168.1.66 -> 192.168.1.20
- 🔴 **SYN Flood** - Possible SYN flood against 192.168.1.20:80
- 🔴 **Suspicious Port** - Data exchanged on suspicious port 4444: 192.168.1.10 -> 198.51.100.77
- 🔴 **Beaconing** - Periodic connections (beaconing): 192.168.1.10 -> 198.51.100.77:4444
- 🔴 **DNS Tunneling** - Possible DNS tunneling/exfiltration: 192.168.1.12 -> *.c2-lab.example
- 🔴 **ARP Spoofing** - Multiple MAC addresses claim 192.168.1.1
- 🔴 **Cleartext Protocol** - Unencrypted Telnet traffic observed
- 🔴 **Cleartext Credentials** - Credentials sent in cleartext

## 2. Capture Overview

| Metric | Value |
|---|---|
| Packets | 1,151 |
| Total size | 98.1 KB |
| Start / End | 2024-10-27 03:33:20 UTC / 2024-10-27 03:39:00 UTC |
| Duration | 340.01 s |
| Average rate | 3.39 packets/s |
| Average packet size | 87.3 bytes |
| Unique IP hosts | 205 (31 internal) |

## 3. Protocol Distribution

**Transport / network layer**

| Protocol | Packets | Share | |
|---|---:|---:|---|
| TCP | 950 | 82.5% | █████████████████ |
| UDP | 140 | 12.2% | ██ |
| ICMP | 43 | 3.7% | █ |
| ARP | 18 | 1.6% | █ |

**Application layer (TCP/UDP)**

| Application | Packets | Bytes |
|---|---:|---:|
| HTTP | 355 | 20.9 KB |
| Other | 300 | 16.5 KB |
| TLS | 212 | 37.8 KB |
| DNS | 130 | 13.4 KB |
| FTP | 23 | 1.3 KB |
| Telnet | 23 | 1.3 KB |
| NTP | 12 | 1.1 KB |
| DHCP | 4 | 224 B |
| SSH | 3 | 170 B |
| FTP-Data | 2 | 112 B |
| SMTP | 2 | 112 B |
| TFTP | 2 | 112 B |
| RPC | 2 | 112 B |
| MSRPC | 2 | 112 B |
| NetBIOS | 2 | 112 B |
| IMAP | 2 | 112 B |
| SMB | 2 | 112 B |
| IMAPS | 2 | 112 B |
| POP3S | 2 | 112 B |
| PPTP | 2 | 112 B |
| MySQL | 2 | 112 B |
| RDP | 2 | 112 B |
| VNC | 2 | 112 B |

## 4. Top Talkers and Conversations

| Host | Scope | Packets sent | Bytes sent |
|---|---|---:|---:|
| `203.0.113.10` | external | 90 | 22.6 KB |
| `192.168.1.10` | internal | 145 | 11.3 KB |
| `192.168.1.12` | internal | 104 | 11.3 KB |
| `192.168.1.66` | internal | 147 | 8.8 KB |
| `192.168.1.20` | internal | 152 | 8.7 KB |
| `192.168.1.11` | internal | 72 | 7.3 KB |
| `192.168.1.1` | internal | 69 | 7.2 KB |
| `198.51.100.77` | external | 48 | 2.7 KB |
| `203.0.113.123` | external | 6 | 540 B |
| `198.51.100.191` | external | 6 | 348 B |

| Host A | Host B | Packets | Bytes |
|---|---|---:|---:|
| `192.168.1.20` | `192.168.1.66` | 232 | 12.7 KB |
| `192.168.1.10` | `203.0.113.10` | 70 | 12.6 KB |
| `192.168.1.12` | `203.0.113.10` | 70 | 12.6 KB |
| `192.168.1.11` | `203.0.113.10` | 70 | 12.6 KB |
| `192.168.1.1` | `192.168.1.12` | 104 | 11.3 KB |
| `192.168.1.10` | `198.51.100.77` | 120 | 6.7 KB |
| `192.168.1.10` | `192.168.1.20` | 40 | 2.9 KB |
| `192.168.1.11` | `192.168.1.20` | 30 | 1.9 KB |
| `192.168.1.1` | `192.168.1.10` | 16 | 1.3 KB |
| `192.168.1.1` | `192.168.1.11` | 16 | 1.3 KB |

## 5. Port Analysis (by destination port)

| Proto | Port | Service | Packets | Note |
|---|---:|---|---:|---|
| TCP | 80 | HTTP | 332 | 🔓 cleartext protocol |
| TCP | 443 | TLS | 121 |  |
| TCP | 40001 | - | 113 |  |
| TCP | 4444 | - | 72 | ⚠️ suspicious port |
| UDP | 53 | DNS | 64 |  |
| TCP | 21 | FTP | 13 | 🔓 cleartext protocol |
| TCP | 23 | Telnet | 13 | 🔓 cleartext protocol |
| TCP | 55439 | - | 9 |  |
| TCP | 60174 | - | 9 |  |
| UDP | 123 | NTP | 6 |  |
| TCP | 55921 | - | 6 |  |
| TCP | 57088 | - | 6 |  |
| TCP | 51986 | - | 6 |  |
| TCP | 61029 | - | 6 |  |
| TCP | 51207 | - | 6 |  |

## 6. Detailed Findings

### F-01 🔴 [High] TCP SYN port scan: 192.168.1.66 -> 192.168.1.20

- **Category:** Port Scan
- **MITRE ATT&CK:** T1046 Network Service Discovery

192.168.1.66 sent bare SYN packets to 113 different TCP ports on 192.168.1.20 in 2.2s (50 ports/s). Probing many ports quickly is the signature of reconnaissance tools such as Nmap.

**Evidence**

- Source: 192.168.1.66   Target: 192.168.1.20
- Distinct ports probed: 113 (first seen 2024-10-27 03:34:05 UTC)
- Ports that answered SYN-ACK (open): 21, 22, 23, 80

**Recommendation:** Block or rate-limit the source, enable IDS port-scan rules, and close unused services on the target. Investigate how the source host got on the network.

### F-02 🔴 [High] Possible SYN flood against 192.168.1.20:80

- **Category:** SYN Flood
- **MITRE ATT&CK:** T1498 Network Denial of Service

306 connection requests (SYN) hit 192.168.1.20:80 (peak 101/s) from 174 source addresses, but only 5% were completed with a final ACK. Half-open connections exhaust a server's connection table.

**Evidence**

- Target: 192.168.1.20:80 (HTTP)
- SYNs: 306   Peak rate: 101/s   Unique sources: 174   Handshakes completed (approx.): 15
- Window: 2024-10-27 03:33:32 UTC -> 2024-10-27 03:36:03 UTC

**Recommendation:** Enable SYN cookies, tune backlog/timeouts, apply upstream rate-limiting or DDoS protection, and use ingress filtering (BCP 38) against spoofed sources.

### F-03 🔴 [High] Data exchanged on suspicious port 4444: 192.168.1.10 -> 198.51.100.77

- **Category:** Suspicious Port
- **MITRE ATT&CK:** T1571 Non-Standard Port

192.168.1.10 exchanged application data with 198.51.100.77 on port 4444, which is associated with: Metasploit default handler / common reverse shell. Legitimate software rarely uses this port.

**Evidence**

- 192.168.1.10 -> 198.51.100.77:4444/tcp (Metasploit default handler / common reverse shell): 72 pkts, 4128 bytes
- Active 2024-10-27 03:33:29 UTC -> 2024-10-27 03:39:00 UTC

**Recommendation:** Identify the process on the internal host owning this connection, block the destination at the firewall, and run an endpoint malware scan.

### F-04 🔴 [High] Periodic connections (beaconing): 192.168.1.10 -> 198.51.100.77:4444

- **Category:** Beaconing
- **MITRE ATT&CK:** T1071 Application Layer Protocol

192.168.1.10 opened 12 new connections to 198.51.100.77:4444 at an almost constant interval (mean 30.1s, jitter 0.7s). Humans do not behave this regularly; malware 'check-ins' to a command-and-control server do.

**Evidence**

- Connections: 12   Mean interval: 30.1s   Std-dev: 0.68s   CV: 0.02
- First: 2024-10-27 03:33:29 UTC   Last: 2024-10-27 03:38:59 UTC
- Destination is external

**Recommendation:** Check the destination's reputation, find the originating process, and isolate the host if the traffic is not explained by a known application.

### F-05 🔴 [High] Possible DNS tunneling/exfiltration: 192.168.1.12 -> *.c2-lab.example

- **Category:** DNS Tunneling
- **MITRE ATT&CK:** T1071.004 Application Layer Protocol: DNS

192.168.1.12 sent 40 DNS queries for 40 unique, unusually long, high-entropy sub-domains of c2-lab.example. Data can be smuggled out inside DNS names, bypassing most firewalls.

**Evidence**

- Client: 192.168.1.12   Parent domain: c2-lab.example
- Queries: 40   Unique sub-domains: 40
- Avg sub-domain length: 45 chars   Avg entropy: 4.44 bits/char
- Example: 5phnqtf76q4vixjfk2vvkpvj2bhhuc2ec6lykopzipwbk.c2-lab.example

**Recommendation:** Block the domain, force clients through a monitored resolver, and alert on long/high-entropy names and abnormal TXT/NULL query volume.

### F-06 🔴 [High] Multiple MAC addresses claim 192.168.1.1

- **Category:** ARP Spoofing
- **MITRE ATT&CK:** T1557.002 ARP Cache Poisoning

Several hardware addresses announced ownership of 192.168.1.1. An attacker can poison ARP caches this way to become a man-in-the-middle.

**Evidence**

- 52:54:00:de:ad:66: 12 ARP packets
- 00:11:22:33:44:01: 3 ARP packets

**Recommendation:** Identify the rogue MAC via the switch CAM table, enable Dynamic ARP Inspection / port security, and use static ARP entries for critical hosts.

### F-07 🔴 [High] Unencrypted Telnet traffic observed

- **Category:** Cleartext Protocol
- **MITRE ATT&CK:** T1040 Network Sniffing

Telnet carries data without encryption, so anyone on the path can read or alter it.

**Evidence**

- 192.168.1.12 <-> 192.168.1.20 port 23: 7 data packets

**Recommendation:** Replace Telnet with SSH and disable the Telnet service.

### F-08 🔴 [High] Credentials sent in cleartext

- **Category:** Cleartext Credentials
- **MITRE ATT&CK:** T1040 Network Sniffing

Usernames and passwords were visible in packet payloads. Anyone capturing this traffic could reuse them. (Passwords are masked in this report.)

**Evidence**

- HTTP Basic Auth: 192.168.1.11 -> 192.168.1.20  user='student'  password='l********' (masked)
- FTP: 192.168.1.11 -> 192.168.1.20  user='student'  password='f********' (masked)

**Recommendation:** Rotate the exposed credentials immediately and move the service to an encrypted protocol with MFA where possible.

### F-09 🟠 [Medium] ICMP ping sweep from 192.168.1.66

- **Category:** Host Sweep
- **MITRE ATT&CK:** T1018 Remote System Discovery

192.168.1.66 sent ICMP echo requests to 30 distinct hosts between 2024-10-27 03:33:50 UTC and 2024-10-27 03:33:51 UTC. Sweeps map which hosts are alive.

**Evidence**

- Source: 192.168.1.66
- Distinct hosts pinged: 30

**Recommendation:** Confirm whether this is an authorised scanner; otherwise isolate the host. Consider rate-limiting ICMP between user segments.

### F-10 🟠 [Medium] Excessive NXDOMAIN replies to 192.168.1.12

- **Category:** DNS Anomaly
- **MITRE ATT&CK:** T1568.002 Dynamic Resolution: DGA

192.168.1.12 received 40 'domain does not exist' replies. High NXDOMAIN rates are typical of DGA malware or DNS tunnelling.

**Evidence**

- Client: 192.168.1.12   NXDOMAIN responses: 40

**Recommendation:** Review the queried names; investigate the host for malware.

### F-11 🟠 [Medium] Unencrypted FTP traffic observed

- **Category:** Cleartext Protocol
- **MITRE ATT&CK:** T1040 Network Sniffing

FTP carries data without encryption, so anyone on the path can read or alter it.

**Evidence**

- 192.168.1.11 <-> 192.168.1.20 port 21: 7 data packets

**Recommendation:** Replace FTP with SFTP or FTPS and disable anonymous/clear logins.

### F-12 🟠 [Medium] Unencrypted HTTP traffic observed

- **Category:** Cleartext Protocol
- **MITRE ATT&CK:** T1040 Network Sniffing

HTTP carries data without encryption, so anyone on the path can read or alter it.

**Evidence**

- 192.168.1.10 <-> 192.168.1.20 port 80: 8 data packets
- 192.168.1.11 <-> 192.168.1.20 port 80: 2 data packets

**Recommendation:** Serve the site over HTTPS (TLS), redirect HTTP to HTTPS and enable HSTS.

## 7. Method and Limitations

Packets were decoded offline from the capture file and aggregated per host, port, flow and protocol. Detections are **heuristics**: thresholds are listed below and can be tuned. A finding is an *indicator to investigate*, not proof of compromise, and legitimate scanners, backup jobs or monitoring tools can look similar. Encrypted payloads (TLS/SSH) cannot be inspected beyond metadata. Passwords are masked in this report.

| Threshold | Value |
|---|---|
| `scan_ports` | 15 |
| `sweep_hosts` | 10 |
| `syn_flood_syns` | 100 |
| `syn_flood_completion` | 0.2 |
| `beacon_min_events` | 8 |
| `beacon_max_cv` | 0.2 |
| `beacon_min_interval` | 1.0 |
| `dns_unique_subdomains` | 15 |
| `dns_long_label` | 30 |
| `nxdomain_min` | 10 |
| `exfil_bytes` | 5000000 |
