"""Dependency-free reader for libpcap (.pcap) and pcapng (.pcapng) captures.

Decodes Ethernet / Linux-cooked / raw-IP frames into lightweight ``Packet``
objects (ARP, IPv4, IPv6, TCP, UDP, ICMP, plus DNS question parsing).
Files saved by Wireshark, tshark, tcpdump or Scapy are all supported.
"""
from __future__ import annotations

import socket
import struct
from dataclasses import dataclass
from typing import Iterator, Optional, Tuple

# TCP flag bits
FIN, SYN, RST, PSH, ACK, URG = 0x01, 0x02, 0x04, 0x08, 0x10, 0x20

LINKTYPE_ETHERNET = 1
LINKTYPE_RAW = (101, 228, 229)
LINKTYPE_LINUX_SLL = 113

SERVICE_PORTS = {
    20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    67: "DHCP", 68: "DHCP", 69: "TFTP", 80: "HTTP", 110: "POP3", 111: "RPC",
    123: "NTP", 135: "MSRPC", 137: "NetBIOS", 138: "NetBIOS", 139: "NetBIOS",
    143: "IMAP", 161: "SNMP", 162: "SNMP", 389: "LDAP", 443: "TLS", 445: "SMB",
    465: "SMTPS", 514: "Syslog", 587: "SMTP", 636: "LDAPS", 993: "IMAPS",
    995: "POP3S", 1433: "MSSQL", 1521: "Oracle", 1723: "PPTP", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 8080: "HTTP", 8443: "TLS",
}

# Protocols that send data (and often credentials) without encryption.
CLEARTEXT_APPS = {"FTP", "Telnet", "HTTP", "POP3", "IMAP", "SNMP", "TFTP", "LDAP"}

_HTTP_STARTS = (b"GET ", b"POST ", b"PUT ", b"HEAD ", b"DELETE ", b"OPTIONS ", b"HTTP/")


@dataclass
class Packet:
    ts: float
    length: int
    proto: str = "OTHER"          # TCP, UDP, ICMP, ICMPv6, ARP, OTHER
    eth_src: Optional[str] = None
    eth_dst: Optional[str] = None
    src_ip: Optional[str] = None
    dst_ip: Optional[str] = None
    src_port: Optional[int] = None
    dst_port: Optional[int] = None
    tcp_flags: Optional[int] = None
    ttl: Optional[int] = None
    payload: bytes = b""
    icmp_type: Optional[int] = None
    arp_op: Optional[int] = None
    arp_sender_mac: Optional[str] = None
    arp_sender_ip: Optional[str] = None
    arp_target_ip: Optional[str] = None
    app: Optional[str] = None     # application-layer guess
    dns: Optional[Tuple[str, bool, int, int]] = None  # (qname, is_response, rcode, qtype)


def service_name(port: Optional[int]) -> str:
    return SERVICE_PORTS.get(port, "") if port is not None else ""


def _mac(b: bytes) -> str:
    return ":".join(f"{x:02x}" for x in b)


# --------------------------------------------------------------------------- #
# Frame decoding
# --------------------------------------------------------------------------- #
def decode_frame(data: bytes, linktype: int, ts: float, orig_len: int = 0) -> Packet:
    pkt = Packet(ts=ts, length=orig_len or len(data))
    etype = None
    l3 = b""
    if linktype == LINKTYPE_ETHERNET:
        if len(data) < 14:
            return pkt
        pkt.eth_dst, pkt.eth_src = _mac(data[0:6]), _mac(data[6:12])
        etype = struct.unpack("!H", data[12:14])[0]
        off = 14
        while etype in (0x8100, 0x88A8) and len(data) >= off + 4:   # VLAN tags
            etype = struct.unpack("!H", data[off + 2:off + 4])[0]
            off += 4
        l3 = data[off:]
    elif linktype == LINKTYPE_LINUX_SLL:
        if len(data) < 16:
            return pkt
        if data[4:6] == b"\x00\x06":
            pkt.eth_src = _mac(data[6:12])
        etype = struct.unpack("!H", data[14:16])[0]
        l3 = data[16:]
    elif linktype in LINKTYPE_RAW:
        if not data:
            return pkt
        etype = 0x0800 if (data[0] >> 4) == 4 else 0x86DD
        l3 = data
    else:
        return pkt

    if etype == 0x0806:
        _decode_arp(pkt, l3)
    elif etype == 0x0800:
        _decode_ipv4(pkt, l3)
    elif etype == 0x86DD:
        _decode_ipv6(pkt, l3)
    return pkt


def _decode_arp(pkt: Packet, d: bytes) -> None:
    if len(d) < 28:
        return
    op = struct.unpack("!H", d[6:8])[0]
    pkt.proto = "ARP"
    pkt.arp_op = op
    pkt.arp_sender_mac = _mac(d[8:14])
    pkt.arp_sender_ip = socket.inet_ntoa(d[14:18])
    pkt.arp_target_ip = socket.inet_ntoa(d[24:28])


def _decode_ipv4(pkt: Packet, d: bytes) -> None:
    if len(d) < 20:
        return
    ihl = (d[0] & 0x0F) * 4
    total = struct.unpack("!H", d[2:4])[0]
    frag = struct.unpack("!H", d[6:8])[0] & 0x1FFF
    pkt.ttl = d[8]
    proto = d[9]
    pkt.src_ip, pkt.dst_ip = socket.inet_ntoa(d[12:16]), socket.inet_ntoa(d[16:20])
    end = total if ihl <= total <= len(d) else len(d)   # trims Ethernet padding
    pkt.proto = f"IP/{proto}"
    if frag == 0:
        _decode_transport(pkt, proto, d[ihl:end])


def _decode_ipv6(pkt: Packet, d: bytes) -> None:
    if len(d) < 40:
        return
    nxt = d[6]
    pkt.ttl = d[7]
    pkt.src_ip = socket.inet_ntop(socket.AF_INET6, d[8:24])
    pkt.dst_ip = socket.inet_ntop(socket.AF_INET6, d[24:40])
    plen = struct.unpack("!H", d[4:6])[0]
    pkt.proto = f"IP/{nxt}"
    _decode_transport(pkt, nxt, d[40:40 + plen] if plen else d[40:])


def _decode_transport(pkt: Packet, proto: int, b: bytes) -> None:
    if proto == 6 and len(b) >= 20:
        sport, dport, _seq, _ack, off_flags = struct.unpack("!HHIIH", b[:14])
        pkt.proto, pkt.src_port, pkt.dst_port = "TCP", sport, dport
        pkt.tcp_flags = off_flags & 0x3F
        pkt.payload = b[(off_flags >> 12) * 4:]
    elif proto == 17 and len(b) >= 8:
        sport, dport = struct.unpack("!HH", b[:4])
        pkt.proto, pkt.src_port, pkt.dst_port = "UDP", sport, dport
        pkt.payload = b[8:]
    elif proto == 1 and len(b) >= 4:
        pkt.proto, pkt.icmp_type = "ICMP", b[0]
        pkt.payload = b[8:]
    elif proto == 58 and len(b) >= 4:
        pkt.proto, pkt.icmp_type = "ICMPv6", b[0]
        pkt.payload = b[8:]
    if pkt.proto in ("TCP", "UDP"):
        _classify(pkt)


def _classify(pkt: Packet) -> None:
    pl = pkt.payload
    if pkt.proto == "UDP" and 53 in (pkt.src_port, pkt.dst_port):
        pkt.dns = parse_dns(pl)
        if pkt.dns:
            pkt.app = "DNS"
            return
    if pl.startswith(_HTTP_STARTS):
        pkt.app = "HTTP"
    elif len(pl) > 2 and pl[0] == 0x16 and pl[1] == 0x03:
        pkt.app = "TLS"
    else:
        pkt.app = (SERVICE_PORTS.get(pkt.dst_port) or SERVICE_PORTS.get(pkt.src_port)
                   or "Other")


def parse_dns(payload: bytes):
    """Return (qname, is_response, rcode, qtype) for the first question, or None."""
    if len(payload) < 12:
        return None
    _ident, flags, qd = struct.unpack("!HHH", payload[:6])
    if qd < 1:
        return None
    labels, i = [], 12
    while i < len(payload):
        n = payload[i]
        if n == 0:
            i += 1
            break
        if n & 0xC0:
            return None
        labels.append(payload[i + 1:i + 1 + n].decode("ascii", "replace"))
        i += 1 + n
    else:
        return None
    qtype = struct.unpack("!H", payload[i:i + 2])[0] if i + 2 <= len(payload) else 0
    return ".".join(labels).lower(), bool(flags & 0x8000), flags & 0xF, qtype


# --------------------------------------------------------------------------- #
# File readers
# --------------------------------------------------------------------------- #
def iter_packets(path: str) -> Iterator[Packet]:
    """Yield decoded packets from a .pcap or .pcapng file."""
    with open(path, "rb") as f:
        magic = f.read(4)
        if magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1",
                     b"\xa1\xb2\xc3\xd4", b"\xa1\xb2\x3c\x4d"):
            yield from _read_pcap(f, magic)
        elif magic == b"\x0a\x0d\x0d\x0a":
            f.seek(0)
            yield from _read_pcapng(f)
        else:
            raise ValueError(f"{path}: not a pcap/pcapng file (magic={magic.hex()})")


def _read_pcap(f, magic: bytes) -> Iterator[Packet]:
    endian = "<" if magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1") else ">"
    nano = magic in (b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d")
    hdr = f.read(20)
    if len(hdr) < 20:
        return
    _maj, _min, _tz, _sig, _snap, link = struct.unpack(endian + "HHiIII", hdr)
    link &= 0x0FFFFFFF
    div = 1e9 if nano else 1e6
    while True:
        rec = f.read(16)
        if len(rec) < 16:
            return
        sec, frac, incl, orig = struct.unpack(endian + "IIII", rec)
        data = f.read(incl)
        if len(data) < incl:
            return
        yield decode_frame(data, link, sec + frac / div, orig)


def _read_pcapng(f) -> Iterator[Packet]:
    endian = "<"
    ifaces = []   # (linktype, seconds-per-tick)
    while True:
        head = f.read(8)
        if len(head) < 8:
            return
        if head[:4] == b"\x0a\x0d\x0d\x0a":                 # Section Header Block
            bom = f.read(4)
            endian = "<" if bom == b"\x4d\x3c\x2b\x1a" else ">"
            total = struct.unpack(endian + "I", head[4:8])[0]
            f.read(max(total - 12, 0))
            ifaces = []
            continue
        btype, total = struct.unpack(endian + "II", head)
        body = f.read(max(total - 12, 0))
        f.read(4)
        if btype == 1 and len(body) >= 8:                    # Interface Description
            link, _res, _snap = struct.unpack(endian + "HHI", body[:8])
            res, o = 1e-6, 8
            while o + 4 <= len(body):
                code, ln = struct.unpack(endian + "HH", body[o:o + 4])
                if code == 0:
                    break
                if code == 9 and ln >= 1:
                    v = body[o + 4]
                    res = 2.0 ** -(v & 0x7F) if v & 0x80 else 10.0 ** -v
                o += 4 + ((ln + 3) & ~3)
            ifaces.append((link, res))
        elif btype == 6 and len(body) >= 20 and ifaces:      # Enhanced Packet
            idx, hi, lo, cap, orig = struct.unpack(endian + "IIIII", body[:20])
            link, res = ifaces[idx] if idx < len(ifaces) else ifaces[0]
            yield decode_frame(body[20:20 + cap], link, ((hi << 32) | lo) * res, orig)
        elif btype == 3 and len(body) >= 4 and ifaces:       # Simple Packet
            orig = struct.unpack(endian + "I", body[:4])[0]
            yield decode_frame(body[4:4 + orig], ifaces[0][0], 0.0, orig)
