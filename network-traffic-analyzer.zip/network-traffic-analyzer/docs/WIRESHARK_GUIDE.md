# Wireshark / tshark / tcpdump Guide

Use these to **capture** traffic and to **independently verify** every NTA finding. Replace the sample IPs with
the ones from your own report.

## 1. Capturing

| Tool | Command |
|---|---|
| tcpdump | `sudo tcpdump -i eth0 -s 0 -w captures/lab.pcap -c 5000` |
| tcpdump (filtered) | `sudo tcpdump -i eth0 -w captures/lab.pcap 'not port 22'` |
| tshark | `sudo tshark -i eth0 -a duration:120 -w captures/lab.pcapng` |
| Wireshark | *Capture → Options →* choose the lab interface → *Start*; *File → Save As* (pcap or pcapng) |
| Scapy via NTA | `sudo python -m nta capture --iface eth0 --duration 60 --out captures/lab.pcap` |

Tip: on VirtualBox/VMware, capture on the **host-only/internal network adapter** so you see only lab traffic.

## 2. Baseline views (Wireshark *Statistics* menu)

* **Protocol Hierarchy** - what protocols make up the capture. CLI: `tshark -r f.pcap -q -z io,phs`
* **Conversations / Endpoints** - top talkers. CLI: `tshark -r f.pcap -q -z conv,tcp` and `-z endpoints,ip`
* **I/O Graph** - spikes in traffic over time. CLI: `tshark -r f.pcap -q -z io,stat,10`
* **Expert Information** - Wireshark's own anomaly list (retransmissions, duplicate IPs, resets)

## 3. Verifying each NTA finding

| Finding | Wireshark display filter | Also try |
|---|---|---|
| **Port scan** | `tcp.flags.syn==1 && tcp.flags.ack==0 && ip.src==192.168.1.66 && ip.dst==192.168.1.20` | *Statistics → Conversations → TCP*: one source, many destination ports. Open ports: `tcp.flags.syn==1 && tcp.flags.ack==1 && ip.src==192.168.1.20` |
| **Closed-port replies** | `tcp.flags.reset==1 && ip.src==192.168.1.20` | RST/ACK storm = scanner hitting closed ports |
| **Ping sweep** | `icmp.type==8 && ip.src==192.168.1.66` | Count distinct `ip.dst` values |
| **SYN flood** | `tcp.flags.syn==1 && tcp.flags.ack==0 && ip.dst==192.168.1.20 && tcp.dstport==80` | *I/O Graph* with this filter shows the burst; many SYNs, almost no final ACKs |
| **Suspicious port** | `tcp.port==4444` | Right-click → *Follow → TCP Stream* to read the payload |
| **Beaconing** | `ip.dst==198.51.100.77 && tcp.flags.syn==1 && tcp.flags.ack==0` | Add column *Time since previous displayed frame* (`frame.time_delta_displayed`) and look for a constant interval |
| **DNS tunneling** | `dns && dns.qry.name matches "c2-lab\\.example$"` | *Statistics → DNS*; sort by `dns.qry.name.len` for long names |
| **NXDOMAIN burst** | `dns.flags.rcode==3` | |
| **ARP spoofing** | `arp.opcode==2 && arp.src.proto_ipv4==192.168.1.1` | Compare `arp.src.hw_mac` values; check *Expert Info* for "duplicate IP address" (`arp.duplicate-address-detected`) |
| **Cleartext Telnet** | `telnet` | *Follow TCP Stream* shows the login in plain text |
| **Cleartext FTP creds** | `ftp.request.command=="USER" \|\| ftp.request.command=="PASS"` | |
| **HTTP Basic auth** | `http.authorization` | Decode the Base64 value to see `user:password` |

## 4. Handy tshark one-liners

```bash
# Who talks to the suspicious port, and when?
tshark -r samples/sample_traffic.pcap -Y "tcp.port==4444 && tcp.flags.syn==1 && tcp.flags.ack==0" \
       -T fields -e frame.time_relative -e ip.src -e ip.dst

# Top DNS names queried
tshark -r f.pcap -Y "dns.flags.response==0" -T fields -e dns.qry.name | sort | uniq -c | sort -rn | head

# Export HTTP objects / credentials review (lab data only)
tshark -r f.pcap -Y "http.request" -T fields -e ip.src -e http.host -e http.request.uri
```

## 5. Cross-check checklist
1. Run NTA and note each finding's source, target and time window.
2. Apply the matching filter in Wireshark and confirm the same counts.
3. Follow one stream per finding and take a screenshot for the report.
4. Record any disagreement (false positive / threshold issue) and tune `Thresholds` if needed.
